python -m serve.web_server --base-model checkpoints/7B-C-Abs-M144/last --bf16 --port 4179
