from .mme_dataset import MMEDataset
from .mme_task import MMETask
